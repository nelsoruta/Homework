# PMS_JAVA
# Requirements:
 1.Netbeans 8 and above
 
 2.mysql-connector-java-8.0.24.jar
 
 3.jcalendar-1.4.jar
 
 # Project Structure:
 
 Under Source package there is the following Packages:
  
  default_package: Hibernate Configurations
  
  DAO pACAKAGE: contains all Data Acess Operations(Baxk-end)
  
  Models Package: Contains All models that will be used in this project
  
  Util: HibernateUtil
  
  View:Font-end of The project
  
 
